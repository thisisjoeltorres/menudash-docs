package desarrollo.ejercicios;

import java.util.ArrayList;
import java.util.Scanner;

public class DesarrolloEjercicios {

    static Scanner sc = new Scanner(System.in);

    public static void main(String[] args) {
        int opcion = -1;

        while (opcion != 0) {
            System.out.println("");
            System.out.println("== Tus Finanzas ==");
            System.out.println("1. Situacion problema 1 (estructurada)");
            System.out.println("2. Situacion problema 2 (clase Cuenta)");
            System.out.println("3. Situacion problema 3 (herencia y polimorfismo)");
            System.out.println("0. Salir");
            System.out.print("Opcion: ");
            opcion = sc.nextInt();


            if (opcion == 1) {
                situacion1();
            } else if (opcion == 2) {
                situacion2();
            } else if (opcion == 3) {
                situacion3();
            } else if (opcion != 0) {
                System.out.println("Opcion invalida.");
            }
        }
        System.out.println("Chao!");
    }

    // porcentaje de interes segun el tipo de cuenta
    static double porcentaje(int tipo) {
        if (tipo == 1) {
            return 1.5;
        } else if (tipo == 2) {
            return 1.7;
        } else if (tipo == 3) {
            return 1.6;
        } else {
            return 0;
        }
    }


    // SITUACION 1 

    static void situacion1() {
        System.out.print("Cuantas cuentas (N): ");
        int n = sc.nextInt();

        long[] numeros = new long[n];
        String[] fechas = new String[n];
        int[] tipos = new int[n];
        double[] saldos = new double[n];

        // leer los datos
        for (int i = 0; i < n; i++) {
            System.out.println("Cuenta " + (i + 1));
            System.out.print("Numero de cuenta: ");
            numeros[i] = sc.nextLong();
            System.out.print("Fecha de apertura (aaaa/mm/dd): ");
            fechas[i] = sc.next();
            System.out.print("Tipo de cuenta (1: AhorroDiario, 2: CuentaJoven, 3: Tradicional): ");
            tipos[i] = sc.nextInt();
            System.out.print("Saldo: ");
            saldos[i] = sc.nextDouble();
        }

        double totalIntereses = 0;
        double totalSaldos = 0;

        // calcular e imprimir
        for (int i = 0; i < n; i++) {
            double interes = saldos[i] * porcentaje(tipos[i]) / 100;
            double nuevoSaldo = saldos[i] + interes;

            System.out.println("Numero de cuenta: " + numeros[i]);
            System.out.println("Interes mensual: " + interes);
            System.out.println("Saldo con interes: " + nuevoSaldo);
            System.out.println("");

            totalIntereses = totalIntereses + interes;
            totalSaldos = totalSaldos + nuevoSaldo;
        }

        System.out.println("Total de intereses: " + totalIntereses);
        System.out.println("Total de saldos: " + totalSaldos);
    }

    // SITUACION 2 


    static class Cuenta {
        private long numeroCuenta;
        private String fechaApertura;
        private int tipoCuenta;
        private double saldo;


        public Cuenta(long numeroCuenta, String fechaApertura, int tipoCuenta, double saldo) {
            this.numeroCuenta = numeroCuenta;
            this.fechaApertura = fechaApertura;
            this.tipoCuenta = tipoCuenta;
            this.saldo = saldo;
        }

        public long getNumeroCuenta() {
            return numeroCuenta;
        }

        public void setNumeroCuenta(long numeroCuenta) {
            this.numeroCuenta = numeroCuenta;
        }

        public String getFechaApertura() {
            return fechaApertura;
        }

        public void setFechaApertura(String fechaApertura) {
            this.fechaApertura = fechaApertura;
        }

        public int getTipoCuenta() {
            return tipoCuenta;
        }

        public void setTipoCuenta(int tipoCuenta) {
            this.tipoCuenta = tipoCuenta;
        }

        public double getSaldo() {
            return saldo;
        }

        public void setSaldo(double saldo) {
            this.saldo = saldo;
        }

        // calcula el interes del mes
        public double calcular_interes() {
            return saldo * porcentaje(tipoCuenta) / 100;
        }
    }

    static void situacion2() {
        ArrayList<Cuenta> cuentas = new ArrayList<>();
        int op = -1;

        while (op != 0) {
            System.out.println("");
            System.out.println("1. Crear cuenta");
            System.out.println("2. Consultar cuenta");
            System.out.println("3. Total de intereses");
            System.out.println("4. Total de saldos");
            System.out.println("0. Volver");
            System.out.print("Opcion: ");
            op = sc.nextInt();


            if (op == 1) {
                System.out.print("Numero de cuenta: ");
                long numero = sc.nextLong();
                System.out.print("Fecha de apertura (aaaa/mm/dd): ");
                String fecha = sc.next();
                System.out.print("Tipo de cuenta (1, 2 o 3): ");
                int tipo = sc.nextInt();
                System.out.print("Saldo: ");
                double saldo = sc.nextDouble();

                Cuenta c = new Cuenta(numero, fecha, tipo, saldo);
                cuentas.add(c);
                System.out.println("Cuenta creada.");

            } else if (op == 2) {
                System.out.print("Numero de cuenta a consultar: ");
                long numero = sc.nextLong();
                boolean encontrada = false;

                for (int i = 0; i < cuentas.size(); i++) {
                    Cuenta c = cuentas.get(i);
                    if (c.getNumeroCuenta() == numero) {
                        double interes = c.calcular_interes();
                        System.out.println("Numero de cuenta: " + c.getNumeroCuenta());
                        System.out.println("Fecha de apertura: " + c.getFechaApertura());
                        System.out.println("Tipo de cuenta: " + c.getTipoCuenta());
                        System.out.println("Interes mensual: " + interes);
                        System.out.println("Saldo con interes: " + (c.getSaldo() + interes));
                        encontrada = true;
                    }
                }


                if (!encontrada) {
                    System.out.println("No se encontro la cuenta.");
                }

            } else if (op == 3) {
                double total = 0;
                for (int i = 0; i < cuentas.size(); i++) {
                    total = total + cuentas.get(i).calcular_interes();
                }
                System.out.println("Total de intereses: " + total);

            } else if (op == 4) {
                double total = 0;
                for (int i = 0; i < cuentas.size(); i++) {
                    Cuenta c = cuentas.get(i);
                    total = total + c.getSaldo() + c.calcular_interes();
                }
                System.out.println("Total de saldos: " + total);

            } else if (op != 0) {
                System.out.println("Opcion invalida.");
            }
        }
    }

    // SITUACION 3 

    
    static class Cliente {
        private long documento;
        private String nombre;
        private String correo;
        private int celular;
        private String direccion;

        public Cliente(long documento, String nombre, String correo, int celular, String direccion) {
            this.documento = documento;
            this.nombre = nombre;
            this.correo = correo;
            this.celular = celular;
            this.direccion = direccion;
        }

        public long getDocumento() {
            return documento;
        }

        public String getNombre() {
            return nombre;
        }

        public String getCorreo() {
            return correo;
        }

        public int getCelular() {
            return celular;
        }

        public String getDireccion() {
            return direccion;
        }
    }

    // las dos cuentas tienen este metodo (asi se usa el polimorfismo)
    interface Interes {
        double calcular_interes();
    }

    // Cuenta hereda de Cliente
    static class CuentaAhorro extends Cliente implements Interes {
        private long numeroCuenta;
        private String fechaApertura;
        private int tipoCuenta;
        private double saldo;

        public CuentaAhorro(long documento, String nombre, String correo, int celular, String direccion,
                long numeroCuenta, String fechaApertura, int tipoCuenta, double saldo) {
            super(documento, nombre, correo, celular, direccion);
            this.numeroCuenta = numeroCuenta;
            this.fechaApertura = fechaApertura;
            this.tipoCuenta = tipoCuenta;
            this.saldo = saldo;
        }

        public long getNumeroCuenta() {
            return numeroCuenta;
        }

        public double getSaldo() {
            return saldo;
        }

        public double calcular_interes() {
            return saldo * porcentaje(tipoCuenta) / 100;
        }
    }

    // CuentaCorriente tambien hereda de Cliente
    static class CuentaCorriente extends Cliente implements Interes {
        private long numeroCuenta;
        private String fechaApertura;
        private double saldo;
        private double porcentajeInteres;
        private double sobregiro;

        public CuentaCorriente(long documento, String nombre, String correo, int celular, String direccion,
                long numeroCuenta, String fechaApertura, double saldo, double porcentajeInteres, double sobregiro) {
            super(documento, nombre, correo, celular, direccion);
            this.numeroCuenta = numeroCuenta;
            this.fechaApertura = fechaApertura;
            this.saldo = saldo;
            this.porcentajeInteres = porcentajeInteres;
            this.sobregiro = sobregiro;
        }

        public long getNumeroCuenta() {
            return numeroCuenta;
        }

        public double getSaldo() {
            return saldo;
        }

        public double getSobregiro() {
            return sobregiro;
        }

        public double calcular_interes() {
            return saldo * porcentajeInteres / 100;
        }
    }

    static void situacion3() {
        // una sola lista con los dos tipos de cuenta
        ArrayList<Cliente> cuentas = new ArrayList<>();
        int op = -1;

        while (op != 0) {
            System.out.println("");
            System.out.println("1. Crear cuenta de ahorro");
            System.out.println("2. Crear cuenta corriente");
            System.out.println("3. Mostrar cuentas");
            System.out.println("4. Total de intereses");
            System.out.println("0. Volver");
            System.out.print("Opcion: ");
            op = sc.nextInt();

            if (op == 1 || op == 2) {
                // datos del cliente
                System.out.print("Documento: ");
                long documento = sc.nextLong();
                sc.nextLine(); // limpiar el enter
                System.out.print("Nombre: ");
                String nombre = sc.nextLine();
                System.out.print("Correo: ");
                String correo = sc.nextLine();
                System.out.print("Celular: ");
                int celular = sc.nextInt();
                sc.nextLine();
                System.out.print("Direccion: ");
                String direccion = sc.nextLine();

                // datos de la cuenta
                System.out.print("Numero de cuenta: ");
                long numero = sc.nextLong();
                System.out.print("Fecha de apertura (aaaa/mm/dd): ");
                String fecha = sc.next();

                if (op == 1) {
                    System.out.print("Tipo de cuenta (1, 2 o 3): ");
                    int tipo = sc.nextInt();
                    System.out.print("Saldo: ");
                    double saldo = sc.nextDouble();
                    cuentas.add(new CuentaAhorro(documento, nombre, correo, celular, direccion, numero, fecha, tipo, saldo));
                } else {
                    System.out.print("Saldo: ");
                    double saldo = sc.nextDouble();
                    System.out.print("Porcentaje de interes mensual: ");
                    double porcentajeInteres = sc.nextDouble();
                    System.out.print("Sobregiro permitido: ");
                    double sobregiro = sc.nextDouble();
                    cuentas.add(new CuentaCorriente(documento, nombre, correo, celular, direccion, numero, fecha, saldo, porcentajeInteres, sobregiro));
                }
                System.out.println("Cuenta creada.");

            } else if (op == 3) {
                for (int i = 0; i < cuentas.size(); i++) {
                    Cliente c = cuentas.get(i);
                    System.out.println("Cliente: " + c.getNombre() + " (" + c.getDocumento() + ")");
                    System.out.println("Correo: " + c.getCorreo() + " - Celular: " + c.getCelular());
                    System.out.println("Direccion: " + c.getDireccion());

                    if (c instanceof CuentaAhorro) {
                        CuentaAhorro a = (CuentaAhorro) c;
                        System.out.println("Cuenta de ahorro " + a.getNumeroCuenta() + " - Saldo: " + a.getSaldo());
                        System.out.println("Interes mensual: " + a.calcular_interes());
                    } else if (c instanceof CuentaCorriente) {
                        CuentaCorriente cc = (CuentaCorriente) c;
                        System.out.println("Cuenta corriente " + cc.getNumeroCuenta() + " - Saldo: " + cc.getSaldo());
                        System.out.println("Sobregiro permitido: " + cc.getSobregiro());
                        System.out.println("Interes mensual: " + cc.calcular_interes());
                    }
                    System.out.println("");
                }

            } else if (op == 4) {
                double total = 0;
                for (int i = 0; i < cuentas.size(); i++) {
                    Interes cuenta = (Interes) cuentas.get(i); // polimorfismo
                    total = total + cuenta.calcular_interes();
                }
                System.out.println("Total de intereses: " + total);

            } else if (op != 0) {
                System.out.println("Opcion invalida.");
            }
        }
    }
}
