
package palindromos;

import java.util.Scanner;


public class Palindromos{

	public static void main(String[] args) {
                StringBuilder drow=new StringBuilder();
                Scanner scan=new Scanner(System.in);
                
                System.out.println("-------Detector de palindromo-----\n");
                System.out.println("Ingrese una palabra:");
                String word=scan.nextLine();
                
                
                for(int i=word.length();i>0;i--){
                    char letra=word.charAt(i-1);
                    drow.append(letra);
                    
                }
                System.out.println(drow);
                if (drow.toString().equalsIgnoreCase(word)){
                    System.out.println("si es un palindromo");
                }else{
                    System.out.println("No es un palindromo");
                }
                
	}

}
