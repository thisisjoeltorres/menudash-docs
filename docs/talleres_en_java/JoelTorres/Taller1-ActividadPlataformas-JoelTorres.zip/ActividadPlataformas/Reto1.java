package ActividadPlataformas;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author joeltorres
 */
import java.util.Locale;
import java.util.Scanner;


// Reto 1: Equivalente a la primera situacion
public class Reto1 {

    // Retorna el porcentaje de interés mensual segun el tipo de cuenta
    static double porcentajeInteres(int tipo) {
        switch (tipo) {
            case 1:
                return 1.5; // AhorroDiario
            case 2:
                return 1.7; // CuentaJoven
            case 3:
                return 1.6; // Tradicional
            default:
                return 0;
        }
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        sc.useLocale(Locale.US); // decimales con punto

        System.out.print("Cantidad de cuentas (N): ");
        int n = sc.nextInt();

        // Datos de las cuentas, en el orden del enunciado
        long[] numeros = new long[n];
        String[] fechas = new String[n];
        int[] tipos = new int[n];
        double[] saldos = new double[n];

        for (int i = 0; i < n; i++) {
            System.out.println("Cuenta " + (i + 1));
            System.out.print("Numero de cuenta: ");
            numeros[i] = sc.nextLong();
            System.out.print("Fecha de apertura (aaaa/mm/dd): ");
            fechas[i] = sc.next();
            System.out.print("Tipo de cuenta (1: AhorroDiario, 2: CuentaJoven, 3: Tradicional): ");
            tipos[i] = sc.nextInt();
            System.out.print("Saldo: ");
            saldos[i] = sc.nextDouble();
        }

        double totalIntereses = 0;
        double totalSaldos = 0;

        System.out.println("\n--- Liquidacion de intereses ---");
        for (int i = 0; i < n; i++) {
            double interes = saldos[i] * porcentajeInteres(tipos[i]) / 100;
            double nuevoSaldo = saldos[i] + interes;

            totalIntereses += interes;
            totalSaldos += nuevoSaldo;

            // Salida en el orden solicitado
            System.out.println("Numero de cuenta: " + numeros[i]);
            System.out.println("Valor de interes mensual: " + interes);
            System.out.println("Saldo con interes: " + nuevoSaldo);
            System.out.println();
        }

        System.out.println("Valor total de intereses: " + totalIntereses);
        System.out.println("Valor total de los saldos: " + totalSaldos);

        sc.close();
    }
}
