package ActividadPlataformas;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author joeltorres
 */
import java.util.Locale;
import java.util.Scanner;

// Reto 2: se amplía el reto 1 encapsulando los datos en la clase Cuenta
class Cuenta {

    // Atributos privados, en el orden del enunciado
    private long numeroCuenta;
    private String fechaApertura; // aaaa/mm/dd
    private int tipoCuenta;       // 1: AhorroDiario, 2: CuentaJoven, 3: Tradicional
    private double saldo;

    public Cuenta(long numeroCuenta, String fechaApertura, int tipoCuenta, double saldo) {
        this.numeroCuenta = numeroCuenta;
        this.fechaApertura = fechaApertura;
        this.tipoCuenta = tipoCuenta;
        this.saldo = saldo;
    }

    // Getters y setters
    public long getNumeroCuenta() {
        return numeroCuenta;
    }

    public void setNumeroCuenta(long numeroCuenta) {
        this.numeroCuenta = numeroCuenta;
    }

    public String getFechaApertura() {
        return fechaApertura;
    }

    public void setFechaApertura(String fechaApertura) {
        this.fechaApertura = fechaApertura;
    }

    public int getTipoCuenta() {
        return tipoCuenta;
    }

    public void setTipoCuenta(int tipoCuenta) {
        this.tipoCuenta = tipoCuenta;
    }

    public double getSaldo() {
        return saldo;
    }

    public void setSaldo(double saldo) {
        this.saldo = saldo;
    }

    // Mismo cálculo del reto 1 (porcentajeInteres), ahora dentro de la clase
    private double porcentajeInteres() {
        switch (tipoCuenta) {
            case 1:
                return 1.5; // AhorroDiario
            case 2:
                return 1.7; // CuentaJoven
            case 3:
                return 1.6; // Tradicional
            default:
                return 0;
        }
    }

    // Calcula y retorna el valor del interés mensual
    public double calcular_interes() {
        return saldo * porcentajeInteres() / 100;
    }
}

public class Reto2 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        sc.useLocale(Locale.US); // decimales con punto

        System.out.print("Cantidad de cuentas (N): ");
        int n = sc.nextInt();

        // Ahora el arreglo guarda objetos Cuenta en vez de cuatro arreglos
        Cuenta[] cuentas = new Cuenta[n];

        for (int i = 0; i < n; i++) {
            System.out.println("Cuenta " + (i + 1));
            System.out.print("Numero de cuenta: ");
            long numero = sc.nextLong();
            System.out.print("Fecha de apertura (aaaa/mm/dd): ");
            String fecha = sc.next();
            System.out.print("Tipo de cuenta (1: AhorroDiario, 2: CuentaJoven, 3: Tradicional): ");
            int tipo = sc.nextInt();
            System.out.print("Saldo: ");
            double saldo = sc.nextDouble();

            cuentas[i] = new Cuenta(numero, fecha, tipo, saldo);
        }

        double totalIntereses = 0;
        double totalSaldos = 0;

        System.out.println("\n--- Liquidacion de intereses ---");
        for (int i = 0; i < n; i++) {
            double interes = cuentas[i].calcular_interes();
            double nuevoSaldo = cuentas[i].getSaldo() + interes;

            totalIntereses += interes;
            totalSaldos += nuevoSaldo;

            System.out.println("Numero de cuenta: " + cuentas[i].getNumeroCuenta());
            System.out.println("Valor de interes mensual: " + interes);
            System.out.println("Saldo con interes: " + nuevoSaldo);
            System.out.println();
        }

        System.out.println("Valor total de intereses: " + totalIntereses);
        System.out.println("Valor total de los saldos: " + totalSaldos);

        sc.close();
    }
}