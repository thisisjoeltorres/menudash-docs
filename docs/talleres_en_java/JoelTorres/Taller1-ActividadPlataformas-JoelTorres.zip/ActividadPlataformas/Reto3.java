package ActividadPlataformas;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author joeltorres
 */
import java.util.Locale;
import java.util.Scanner;

// Reto 3: se amplía el reto 2 con herencia (Cliente) y polimorfismo (calcular_interes)

// Clase base: solo datos del cliente, sin operaciones propias (solo acceso encapsulado)
class Cliente {

    private long documento;
    private String nombre;
    private String correo;
    private String celular;
    private String direccion; // para comunicaciones y extractos

    public Cliente(long documento, String nombre, String correo, String celular, String direccion) {
        this.documento = documento;
        this.nombre = nombre;
        this.correo = correo;
        this.celular = celular;
        this.direccion = direccion;
    }

    public long getDocumento() {
        return documento;
    }

    public void setDocumento(long documento) {
        this.documento = documento;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getCorreo() {
        return correo;
    }

    public void setCorreo(String correo) {
        this.correo = correo;
    }

    public String getCelular() {
        return celular;
    }

    public void setCelular(String celular) {
        this.celular = celular;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }
}

// Contrato comun de los productos: permite tratar Cuenta y CuentaCorriente a traves del polimorfismo.
interface Liquidable {
    double calcular_interes();

    long getNumeroCuenta();

    double getSaldo();
}

// Clase Cuenta del reto 2, ahora hereda de Cliente
class Cuenta extends Cliente implements Liquidable {

    private long numeroCuenta;
    private String fechaApertura; // aaaa/mm/dd
    private int tipoCuenta;       // 1: AhorroDiario, 2: CuentaJoven, 3: Tradicional
    private double saldo;

    public Cuenta(long documento, String nombre, String correo, String celular, String direccion,
                  long numeroCuenta, String fechaApertura, int tipoCuenta, double saldo) {
        super(documento, nombre, correo, celular, direccion);
        this.numeroCuenta = numeroCuenta;
        this.fechaApertura = fechaApertura;
        this.tipoCuenta = tipoCuenta;
        this.saldo = saldo;
    }

    @Override
    public long getNumeroCuenta() {
        return numeroCuenta;
    }

    public void setNumeroCuenta(long numeroCuenta) {
        this.numeroCuenta = numeroCuenta;
    }

    public String getFechaApertura() {
        return fechaApertura;
    }

    public void setFechaApertura(String fechaApertura) {
        this.fechaApertura = fechaApertura;
    }

    public int getTipoCuenta() {
        return tipoCuenta;
    }

    public void setTipoCuenta(int tipoCuenta) {
        this.tipoCuenta = tipoCuenta;
    }

    @Override
    public double getSaldo() {
        return saldo;
    }

    public void setSaldo(double saldo) {
        this.saldo = saldo;
    }

    private double porcentajeInteres() {
        switch (tipoCuenta) {
            case 1:
                return 1.5; // AhorroDiario
            case 2:
                return 1.7; // CuentaJoven
            case 3:
                return 1.6; // Tradicional
            default:
                return 0;
        }
    }

    @Override
    public double calcular_interes() {
        return saldo * porcentajeInteres() / 100;
    }
}

// Nuevo producto: hereda de Cliente y calcula el interés con su propio porcentaje
class CuentaCorriente extends Cliente implements Liquidable {

    private long numeroCuenta;
    private String fechaApertura; // aaaa/mm/dd
    private double saldo;
    private double porcentajeInteres; // % mensual aplicado al saldo
    private double sobregiro; // valor permitido de sobregiro

    public CuentaCorriente(long documento, String nombre, String correo, String celular, String direccion,
                           long numeroCuenta, String fechaApertura, double saldo,
                           double porcentajeInteres, double sobregiro) {
        super(documento, nombre, correo, celular, direccion);
        this.numeroCuenta = numeroCuenta;
        this.fechaApertura = fechaApertura;
        this.saldo = saldo;
        this.porcentajeInteres = porcentajeInteres;
        this.sobregiro = sobregiro;
    }

    @Override
    public long getNumeroCuenta() {
        return numeroCuenta;
    }

    public void setNumeroCuenta(long numeroCuenta) {
        this.numeroCuenta = numeroCuenta;
    }

    public String getFechaApertura() {
        return fechaApertura;
    }

    public void setFechaApertura(String fechaApertura) {
        this.fechaApertura = fechaApertura;
    }

    @Override
    public double getSaldo() {
        return saldo;
    }

    public void setSaldo(double saldo) {
        this.saldo = saldo;
    }

    public double getPorcentajeInteres() {
        return porcentajeInteres;
    }

    public void setPorcentajeInteres(double porcentajeInteres) {
        this.porcentajeInteres = porcentajeInteres;
    }

    public double getSobregiro() {
        return sobregiro;
    }

    public void setSobregiro(double sobregiro) {
        this.sobregiro = sobregiro;
    }

    // Mismo nombre que en Cuenta, distinta implementación (aka. polimorfismo)
    @Override
    public double calcular_interes() {
        return saldo * porcentajeInteres / 100;
    }
}

public class Reto3 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        sc.useLocale(Locale.US); // decimales con punto

        System.out.print("Cantidad de cuentas (N): ");
        int n = sc.nextInt();

        // Mismo arreglo del reto 2, pero del tipo comun para guardar ambos productos
        Liquidable[] cuentas = new Liquidable[n];

        for (int i = 0; i < n; i++) {
            System.out.println("Cuenta " + (i + 1));
            System.out.print("Producto (1: Cuenta de ahorro, 2: Cuenta corriente): ");
            int producto = sc.nextInt();

            // Datos del cliente
            System.out.print("Documento de identidad: ");
            long documento = sc.nextLong();
            sc.nextLine(); // limpia el salto de línea pendiente
            System.out.print("Nombre: ");
            String nombre = sc.nextLine();
            System.out.print("Correo electronico: ");
            String correo = sc.nextLine();
            System.out.print("Celular: ");
            String celular = sc.nextLine();
            sc.nextLine();
            System.out.print("Direccion: ");
            String direccion = sc.nextLine();

            // Datos de la cuenta
            System.out.print("Numero de cuenta: ");
            long numero = sc.nextLong();
            System.out.print("Fecha de apertura (aaaa/mm/dd): ");
            String fecha = sc.next();

            if (producto == 1) {
                System.out.print("Tipo de cuenta (\n1: AhorroDiario, \n2: CuentaJoven, \n3: Tradicional).\nOpcion: ");
                int tipo = sc.nextInt();
                System.out.print("Saldo: ");
                double saldo = sc.nextDouble();
                cuentas[i] = new Cuenta(documento, nombre, correo, celular, direccion,
                        numero, fecha, tipo, saldo);
            } else {
                System.out.print("Saldo: ");
                double saldo = sc.nextDouble();
                System.out.print("Porcentaje de interes mensual: ");
                double porcentaje = sc.nextDouble();
                System.out.print("Valor permitido de sobregiro: ");
                double sobregiro = sc.nextDouble();
                cuentas[i] = new CuentaCorriente(documento, nombre, correo, celular, direccion,
                        numero, fecha, saldo, porcentaje, sobregiro);
            }
        }

        double totalIntereses = 0;
        double totalSaldos = 0;

        System.out.println("\n--- Liquidacion de intereses ---");
        for (int i = 0; i < n; i++) {
            double interes = cuentas[i].calcular_interes();
            double nuevoSaldo = cuentas[i].getSaldo() + interes;

            totalIntereses += interes;
            totalSaldos += nuevoSaldo;

            System.out.println("Numero de cuenta: " + cuentas[i].getNumeroCuenta());
            System.out.println("Valor de interes mensual: " + interes);
            System.out.println("Saldo con interes: " + nuevoSaldo);
            System.out.println();
        }

        System.out.println("Valor total de intereses: " + totalIntereses);
        System.out.println("Valor total de los saldos: " + totalSaldos);

        sc.close();
    }
}