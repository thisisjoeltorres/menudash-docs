package com.example.demo; // Ajusta esto según el paquete de tu proyecto

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoApplication implements CommandLineRunner {

    public static void main(String[] args) {
        SpringApplication.run(DemoApplication.class, args);
    }

    @Override
    public void run(String... args) throws Exception {
        // Paso 1 y 2: Leer la palabra y guardarla en la variable original
        String palabraOriginal = "reconocer"; // Puedes cambiarla para probar otras palabras
        
        // Copia sobre la que trabajaremos
        String copiaTrabajo = palabraOriginal;
        
        // Variable que llevará la palabra al revés
        String nuevaPalabra = "";
        
        // Obtener la longitud para el loop
        int longitud = copiaTrabajo.length();
        
        // Paso 3: Loop que se inicia con el número de letras de la palabra
        for (int i = 0; i < longitud; i++) {
            char ultimaLetra = copiaTrabajo.charAt(copiaTrabajo.length() - 1);
            
            nuevaPalabra = nuevaPalabra + ultimaLetra;
            
            copiaTrabajo = copiaTrabajo.substring(0, copiaTrabajo.length() - 1);
        }
        
        // Paso 4: Verificamos ambas palabras
        System.out.println("Palabra original: " + palabraOriginal);
        System.out.println("Palabra al revés: " + nuevaPalabra);
        
        if (palabraOriginal.equals(nuevaPalabra)) {
            System.out.println("¡Es un palíndromo!");
        } else {
            System.out.println("No es palíndromo.");
        }
    }
}