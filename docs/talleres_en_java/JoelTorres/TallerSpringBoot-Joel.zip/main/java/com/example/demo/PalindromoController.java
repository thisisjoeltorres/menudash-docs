package com.example.demo;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class PalindromoController {

    @GetMapping("/palindromo")
    public String verificarPalindromo(@RequestParam(name = "palabra", defaultValue = "OJO") String palabraOriginal, Model model) {
        
        // Tu algoritmo paso a paso
        String copiaTrabajo = palabraOriginal;
        String nuevaPalabra = "";
        int longitud = copiaTrabajo.length();
        
        for (int i = 0; i < longitud; i++) {
            char ultimaLetra = copiaTrabajo.charAt(copiaTrabajo.length() - 1);
            nuevaPalabra = nuevaPalabra + ultimaLetra;
            copiaTrabajo = copiaTrabajo.substring(0, copiaTrabajo.length() - 1);
        }
        
        boolean esPalindromo = palabraOriginal.equalsIgnoreCase(nuevaPalabra);
        
        // Inyectamos las variables para pasarlas al archivo HTML
        model.addAttribute("palabraOriginal", palabraOriginal);
        model.addAttribute("nuevaPalabra", nuevaPalabra);
        model.addAttribute("esPalindromo", esPalindromo);
        
        return "palindromo"; // Esto buscará un archivo llamado palindromo.html
    }
}